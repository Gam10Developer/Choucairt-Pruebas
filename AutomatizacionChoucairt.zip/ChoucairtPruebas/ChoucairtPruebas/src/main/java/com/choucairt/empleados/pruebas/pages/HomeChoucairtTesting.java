package com.choucairt.empleos.pruebas.pages;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomeChoucairtTesting {
	By btnEmpleos = By.id("menu-item-550");
	By btnConvocatorias = By.Xpath ("//a[href='#convocatorias']")
	By imgChoucairt = By.Xpath ("//img[class='attacchment-full size-full']");
	

	
	WebDriver gabriel;
	
	public HomechoucairtTesting(WebDriver gabriel) {
		this.gabriel = gabriel;
	}
	
	
	public void clicEnEmpleos() {
		gabriel.findElement(btnEmpleos).click();
	}
	
	public void clicEnConvocatorias() {
		gabriel.findElement(btnConvocatorias).click();
	}
	
	public void validarIngresoSeccionEmpleos() {
		assertThat(gabriel.findElement(imgChoucairt).isDisplayed(), Matchers.is(true));
	}
}
