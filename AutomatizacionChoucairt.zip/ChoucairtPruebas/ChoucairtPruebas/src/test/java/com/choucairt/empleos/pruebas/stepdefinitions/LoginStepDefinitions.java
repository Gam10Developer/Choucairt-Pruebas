package com.choucairt.empleos.pruebas.stepdefinitions;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.newtours.bookflight.pruebas.pages.HomeNewTours;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinitions {

	WebDriver gabriel;
	HomeNewTours home;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Gabriel Andres\\eclipse-workspace\\MyPrimer Serenity\\ChoucairtPruebas\\chromedriver.exe");
		gabriel = new ChromeDriver(); // Abrir el navegador
		home = new HomeChoucairtTesting(gabriel);
	}
	
	@Given("I am in Choucairt HomePage")
	public void iAmInChoucairtHomePage() {
	      gabriel.get("https://www.choucairtesting.com/");
	}

	@When("I Enter The Employees Section")
	public void iEnterTheEmployeesSection() {
		
		home.clicEnEmpleos();
		home.clicEnConvocatorias();
	}

	@Then("I Browse The Employees Section")
	public void iBrowseTheEmployeesSection() {
	    home.validarIngresoSeccionEmpleos();
	    gabriel.quit();
	}
	
}
